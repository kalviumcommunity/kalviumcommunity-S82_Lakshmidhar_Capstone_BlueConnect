
import express from 'express';
import Job from '../models/Job.js';
import { verifyToken } from '../middlewares/authMiddleware.js';

const router = express.Router();


router.post('/', verifyToken, async (req, res) => {
  const { title, description, location, salary } = req.body;

  try {
    if (req.user.role !== 'user') {
      return res.status(403).json({ message: 'Only employers can post jobs.' });
    }

    const job = new Job({
      title,
      description,
      location,
      salary,
      company: req.user.company || 'Not specified',
      postedBy: req.user._id,
    });

    await job.save();
    res.status(201).json(job);
  } catch (error) {
    console.error('Job Post Error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
