import express from 'express';
import Job from '../models/Job.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

// POST: Create new job
router.post('/', protect, async (req, res) => {
  const { title, description, location, category, budget, deadline } = req.body;

  try {
    const job = await Job.create({
      user: req.user._id,
      title,
      description,
      location,
      category,
      budget,
      deadline,
    });

    res.status(201).json(job);
  } catch (error) {
    res.status(400).json({ message: 'Error creating job', error: error.message });
  }
});

// GET: List all jobs
router.get('/', async (req, res) => {
  const jobs = await Job.find().populate('user', 'name email role');
  res.json(jobs);
});

// GET: Single job
router.get('/:id', async (req, res) => {
  try {
    const job = await Job.findById(req.params.id).populate('user', 'name email role');
    if (!job) return res.status(404).json({ message: 'Job not found' });

    res.json(job);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// POST: Apply to a job
router.post('/:id/apply', protect, async (req, res) => {
  const { bidAmount, coverLetter } = req.body;

  try {
    const job = await Job.findById(req.params.id);
    if (!job) return res.status(404).json({ message: 'Job not found' });

    job.applicants.push({
      workerId: req.user._id,
      bidAmount,
      coverLetter,
    });

    await job.save();
    res.status(200).json({ message: 'Application submitted' });
  } catch (error) {
    res.status(500).json({ message: 'Error applying to job' });
  }
});

router.get('/applied/:userId', protect, async (req, res) => {
  try {
    const jobs = await Job.find({ 'applicants.workerId': req.params.userId });
    res.json({ jobs });
  } catch (error) {
    res.status(500).json({ message: 'Error fetching applied jobs', error: error.message });
  }
});

export default router;
